<?php
class Mage_WEBCASH_Model_PaymentMethod_Result extends Varien_Object {  
    
}