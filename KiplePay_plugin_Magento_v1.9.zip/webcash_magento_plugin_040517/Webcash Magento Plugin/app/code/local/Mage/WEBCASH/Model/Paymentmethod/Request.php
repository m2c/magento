<?php
class Mage_WEBCASH_Model_PaymentMethod_Request extends Varien_Object {
    
}